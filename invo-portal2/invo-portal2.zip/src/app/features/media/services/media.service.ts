import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders, HttpEvent, HttpEventType } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, firstValueFrom } from 'rxjs';
import {
  Media,
  FileUploadItem,
  IMediaUploadResult,
  IAttachmentParams,
  IGetAttachmentsParams,
  IMediaUploadConfig
} from '../models/media.model';
import { ImageCompressionService } from './image-compression.service';
import { environment } from '../../../../environments/environment';

/**
 * Enhanced Media Service
 * Modern Angular 21 service with async/await pattern
 */

@Injectable({ providedIn: 'root' })
export class MediaService {
  private http = inject(HttpClient);
  private router = inject(Router);
  private imageCompression = inject(ImageCompressionService);

  private baseUrl = environment.backendUrl;
  private authToken: string = '';

  // Configuration
  static readonly MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB
  static readonly SUPPORTED_IMAGE_TYPES = [
    'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'
  ];
  static readonly SUPPORTED_DOCUMENT_TYPES = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation'
  ];

  // State management
  private uploadQueue$ = new BehaviorSubject<FileUploadItem[]>([]);
  private uploadProgress$ = new BehaviorSubject<Map<string, number>>(new Map());

  // Observable streams
  public readonly uploadQueue = this.uploadQueue$.asObservable();
  public readonly uploadProgress = this.uploadProgress$.asObservable();

  // ── Configuration ─────────────────────────────────────────────────────────

  setAuthToken(token: string): void {
    this.authToken = token;
  }

  setBaseUrl(url: string): void {
    this.baseUrl = url;
  }

  // ── File Validation ───────────────────────────────────────────────────────

  validateFile(file: File, config?: IMediaUploadConfig): { valid: boolean; error?: string } {
    const maxSize = config?.maxFileSize || MediaService.MAX_FILE_SIZE;
    const allowedTypes = config?.allowedTypes || [
      ...MediaService.SUPPORTED_IMAGE_TYPES,
      ...MediaService.SUPPORTED_DOCUMENT_TYPES
    ];

    if (file.size > maxSize) {
      return {
        valid: false,
        error: `File size exceeds maximum allowed size of ${this.formatBytes(maxSize)}`
      };
    }

    if (!allowedTypes.includes(file.type)) {
      return {
        valid: false,
        error: `File type ${file.type} is not supported`
      };
    }

    return { valid: true };
  }

  validateFiles(files: File[], config?: IMediaUploadConfig): Map<string, string | null> {
    const results = new Map<string, string | null>();
    files.forEach(file => {
      const validation = this.validateFile(file, config);
      results.set(file.name, validation.valid ? null : (validation.error || 'Invalid file'));
    });
    return results;
  }

  // ── Upload ────────────────────────────────────────────────────────────────

  /** Upload a single file */
  async uploadFile(file: File, config?: IMediaUploadConfig): Promise<IMediaUploadResult> {
    // Validate
    const validation = this.validateFile(file, config);
    if (!validation.valid) {
      throw new Error(validation.error);
    }

    // Create upload item
    const uploadItem = new FileUploadItem(file);
    this.addToUploadQueue(uploadItem);

    try {
      // Compress if needed
      const preparedFile = await this.prepareFileForUpload(file, config);

      // Upload
      const result = await this.executeUpload(preparedFile, uploadItem.id);

      // Update status
      this.updateUploadItem(uploadItem.id, {
        status: 'completed',
        progress: 100
      });

      return result;
    } catch (error: any) {
      this.updateUploadItem(uploadItem.id, {
        status: 'failed',
        error: error.message || 'Upload failed'
      });
      throw error;
    }
  }

  /** Upload multiple files */
  async uploadFiles(files: File[], config?: IMediaUploadConfig): Promise<IMediaUploadResult[]> {
    const results: IMediaUploadResult[] = [];

    for (const file of files) {
      try {
        const result = await this.uploadFile(file, config);
        results.push(result);
      } catch (error: any) {
        results.push({
          success: false,
          error: error.message || 'Upload failed'
        });
      }
    }

    return results;
  }

  /** Upload multiple files in bulk (single request) */
  async uploadBulk(files: File[], config?: IMediaUploadConfig): Promise<IMediaUploadResult> {
    // Validate all files
    const validationResults = this.validateFiles(files, config);
    const invalidFiles = Array.from(validationResults.entries())
      .filter(([_, error]) => error !== null);

    if (invalidFiles.length > 0) {
      const errors = invalidFiles.map(([name, error]) => `${name}: ${error}`).join(', ');
      throw new Error(errors);
    }

    const formData = new FormData();
    files.forEach((file, index) => {
      formData.append(`files[${index}]`, file);
    });

    const headers = this.getHeaders();

    try {
      const response = await firstValueFrom(
        this.http.post<any>(`${this.baseUrl}media/importMedia`, formData, { headers })
      );
      return {
        success: true,
        data: response.data || [],
        message: 'Bulk upload completed'
      };
    } catch (error: any) {
      this.handleError(error);
      throw {
        success: false,
        error: error.error?.message || error.message || 'Bulk upload failed'
      };
    }
  }

  private async prepareFileForUpload(file: File, config?: IMediaUploadConfig): Promise<File> {
    // Compress if enabled and file is an image
    if (config?.compressionEnabled && this.isImageFile(file)) {
      return await firstValueFrom(
        this.imageCompression.compress(file, {
          maxFileSizeBytes: config.maxFileSize,
          qualityRatio: config.compressionQuality,
          maxWidthPixels: config.maxDimensions?.width,
          maxHeightPixels: config.maxDimensions?.height
        })
      );
    }
    return file;
  }

  private async executeUpload(file: File, uploadId: string): Promise<IMediaUploadResult> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('name', file.name);
    formData.append('type', file.type);
    formData.append('size', file.size.toString());

    const headers = this.getHeaders();

    try {
      // Simple upload without progress tracking for async/await pattern
      const response = await firstValueFrom(
        this.http.post<any>(`${this.baseUrl}media/importMedia`, formData, { headers })
      );

      return {
        success: true,
        data: response.data || [],
        message: 'Upload completed'
      };
    } catch (error: any) {
      this.handleError(error);
      throw {
        success: false,
        error: error.error?.message || error.message || 'Upload failed'
      };
    }
  }

  // ── Media Retrieval ───────────────────────────────────────────────────────

  /** Get all media with optional filters */
  async getAllMedia(filters?: any): Promise<Media[]> {
    const headers = this.getHeaders();

    try {
      const response = await firstValueFrom(
        this.http.post<any>(`${this.baseUrl}media/getMediaList`, filters || {}, { headers })
      );
      return (response.data || []).map((item: any) => new Media(item));
    } catch (error: any) {
      this.handleError(error);
      throw error;
    }
  }

  /** Get media by ID */
  async getMediaById(id: string): Promise<Media> {
    const headers = this.getHeaders();

    try {
      const response = await firstValueFrom(
        this.http.get<any>(`${this.baseUrl}media/getMediabyId/${id}`, { headers })
      );
      return new Media(response.data);
    } catch (error: any) {
      this.handleError(error);
      throw error;
    }
  }

  // ── Media Deletion ────────────────────────────────────────────────────────

  /** Delete media by ID */
  async deleteMedia(id: string): Promise<boolean> {
    const headers = this.getHeaders();

    try {
      const response = await firstValueFrom(
        this.http.post<any>(`${this.baseUrl}media/deleteMedia`, { id }, { headers })
      );
      return response.success || false;
    } catch (error: any) {
      this.handleError(error);
      return false;
    }
  }

  /** Delete multiple media items */
  async deleteMultipleMedia(ids: string[]): Promise<boolean> {
    if (ids.length === 0) return true;

    try {
      // Delete each file individually
      const results = await Promise.all(
        ids.map(id => this.deleteMedia(id))
      );
      return results.every(r => r === true);
    } catch (error: any) {
      console.error('Failed to delete some media:', error);
      return false;
    }
  }

  // ── Attachments ───────────────────────────────────────────────────────────

  /** Append attachments to a reference entity */
  async appendAttachment(params: IAttachmentParams): Promise<boolean> {
    const headers = this.getHeaders();

    try {
      const response = await firstValueFrom(
        this.http.post<any>(`${this.baseUrl}media/appendAttachment`, params, { headers })
      );
      return response.success || false;
    } catch (error: any) {
      this.handleError(error);
      return false;
    }
  }

  /** Get attachments for a reference entity */
  async getAttachments(params: IGetAttachmentsParams): Promise<Media[]> {
    const headers = this.getHeaders();

    try {
      const response = await firstValueFrom(
        this.http.post<any>(`${this.baseUrl}media/getAttachments`, params, { headers })
      );
      return (response.data?.attachment || []).map((item: any) => new Media(item));
    } catch (error: any) {
      this.handleError(error);
      return [];
    }
  }

  /** Delete an attachment */
  async deleteAttachment(params: { reference: string; referenceId: string; attachmentId: string }): Promise<boolean> {
    const headers = this.getHeaders();

    try {
      const response = await firstValueFrom(
        this.http.post<any>(`${this.baseUrl}media/deleteAttachment`, params, { headers })
      );
      return response.success || false;
    } catch (error: any) {
      this.handleError(error);
      return false;
    }
  }

  // ── Download ──────────────────────────────────────────────────────────────

  downloadImage(url: string, filename: string): void {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'blob';

    xhr.onload = () => {
      if (xhr.status === 200) {
        this.triggerDownload(xhr.response, filename);
      }
    };

    xhr.send();
  }

  downloadPDF(media: Media): void {
    if (!media.url.original) return;

    const xhr = new XMLHttpRequest();
    xhr.open('GET', media.url.original, true);
    xhr.responseType = 'blob';

    xhr.onload = () => {
      if (xhr.status === 200) {
        const filename = `${media.name}_${this.formatDate(new Date())}.${media.mediaType.extension}`;
        this.triggerDownload(xhr.response, filename);
      }
    };

    xhr.send();
  }

  private triggerDownload(blob: Blob, filename: string): void {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  // ── Upload Queue Management ───────────────────────────────────────────────

  private addToUploadQueue(item: FileUploadItem): void {
    const currentQueue = this.uploadQueue$.value;
    this.uploadQueue$.next([...currentQueue, item]);
  }

  private updateUploadItem(id: string, updates: Partial<FileUploadItem>): void {
    const currentQueue = this.uploadQueue$.value;
    const updatedQueue = currentQueue.map(item => {
      if (item.id === id) {
        const updated = new FileUploadItem(item.file);
        Object.assign(updated, item, updates);
        return updated;
      }
      return item;
    });
    this.uploadQueue$.next(updatedQueue);
  }

  private updateUploadProgress(id: string, progress: number): void {
    const currentProgress = this.uploadProgress$.value;
    currentProgress.set(id, progress);
    this.uploadProgress$.next(new Map(currentProgress));
  }

  clearCompletedUploads(): void {
    const currentQueue = this.uploadQueue$.value;
    const activeQueue = currentQueue.filter(item =>
      item.status !== 'completed' && item.status !== 'failed'
    );
    this.uploadQueue$.next(activeQueue);
  }

  cancelUpload(id: string): void {
    this.updateUploadItem(id, { status: 'cancelled' });
  }

  // ── Utility Methods ───────────────────────────────────────────────────────

  isImageFile(file: File): boolean {
    return MediaService.SUPPORTED_IMAGE_TYPES.includes(file.type);
  }

  isDocumentFile(file: File): boolean {
    return MediaService.SUPPORTED_DOCUMENT_TYPES.includes(file.type);
  }

  formatBytes(bytes: number): string {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
  }

  private formatDate(date: Date): string {
    return `${date.getFullYear()}_${date.getMonth() + 1}_${date.getDate()}`;
  }

  extractExtension(filename: string): string {
    const dotIndex = filename.lastIndexOf('.');
    return dotIndex !== -1 ? filename.slice(dotIndex + 1) : '';
  }

  getMimeTypeFromExtension(extension: string): string {
    const mimeTypes: Record<string, string> = {
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'gif': 'image/gif',
      'webp': 'image/webp',
      'pdf': 'application/pdf',
      'doc': 'application/msword',
      'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'xls': 'application/vnd.ms-excel',
      'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'ppt': 'application/vnd.ms-powerpoint',
      'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
    };
    return mimeTypes[extension.toLowerCase()] || 'application/octet-stream';
  }

  // ── Helper Methods ────────────────────────────────────────────────────────

  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      'api-auth': this.authToken
    });
  }

  private handleError(error: any): void {
    if (error.status === 401) {
      this.router.navigateByUrl('/login');
    }
  }
}
