import { Component, OnInit, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subject, takeUntil } from 'rxjs';

import { MediaService } from '../services/media.service';
import { Media, IMediaUploadConfig } from '../models/media.model';
import { MediaUploadComponent } from '../components/media-upload.component';
import { MediaGalleryComponent } from '../components/media-gallery.component';
import { MediaPreviewComponent } from '../components/media-preview.component';
import { ModalService } from '../../../shared/modal/modal.service';

/**
 * Media Manager Page
 * Main page for managing all media assets
 */

type ViewTab = 'all' | 'images' | 'documents' | 'videos' | 'audio';

@Component({
  selector: 'app-media-manager',
  standalone: true,
  imports: [
    CommonModule,
    MediaUploadComponent,
    MediaGalleryComponent
  ],
  templateUrl: './media-manager.component.html',
  styleUrls: ['./media-manager.component.scss']
})
export class MediaManagerComponent implements OnInit, OnDestroy {
  // State
  currentTab = signal<ViewTab>('all');
  showUploadPanel = signal(false);
  selectedMedia = signal<Media[]>([]);
  
  // Upload configuration
  uploadConfig: IMediaUploadConfig = {
    maxFileSize: MediaService.MAX_FILE_SIZE,
    compressionEnabled: true,
    compressionQuality: 0.8,
    maxDimensions: { width: 1920, height: 1920 }
  };

  private destroy$ = new Subject<void>();

  constructor(
    private mediaService: MediaService,
    private modalService: ModalService
  ) {}

  ngOnInit(): void {
    // Initialize
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ==================== TAB MANAGEMENT ====================

  setTab(tab: ViewTab): void {
    this.currentTab.set(tab);
  }

  getAllowedTypes(): string[] {
    switch (this.currentTab()) {
      case 'images':
        return ['image'];
      case 'documents':
        return ['docs'];
      case 'videos':
        return ['video'];
      case 'audio':
        return ['audio'];
      default:
        return [];
    }
  }

  // ==================== UPLOAD MANAGEMENT ====================

  toggleUploadPanel(): void {
    this.showUploadPanel.update(show => !show);
  }

  onUploadComplete(media: Media[]): void {
    console.log('Upload completed:', media);
    this.showUploadPanel.set(false);
    // Refresh gallery
  }

  onUploadError(error: string): void {
    console.error('Upload error:', error);
    // Show error notification
  }

  // ==================== MEDIA SELECTION ====================

  onMediaSelected(media: Media[]): void {
    this.selectedMedia.set(media);
  }

  onMediaDeleted(ids: string[]): void {
    console.log('Media deleted:', ids);
    this.selectedMedia.set([]);
    // Refresh gallery
  }

  // ==================== PREVIEW ====================

  openPreview(media: Media, mediaList: Media[] = []): void {
    this.modalService.open(MediaPreviewComponent, {
      size: 'xl',
      data: {
        media,
        mediaList: mediaList.length > 0 ? mediaList : [media],
        title: 'Media Preview'
      }
    });
  }

  // ==================== STATISTICS ====================

  getStatistics() {
    // This would typically come from an API
    return {
      totalMedia: 0,
      totalSize: '0 MB',
      images: 0,
      documents: 0,
      videos: 0,
      audio: 0
    };
  }
}
