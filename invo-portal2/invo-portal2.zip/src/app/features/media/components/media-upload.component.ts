import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subject, takeUntil } from 'rxjs';

import { MediaService } from '../services/media.service';
import { FileUploadItem, Media, IMediaUploadConfig } from '../models/media.model';

/**
 * Media Upload Component
 * Modern Angular 21 component with signals and standalone architecture
 * Features:
 * - Drag & drop file upload
 * - Progress tracking
 * - File validation
 * - Preview thumbnails
 * - Multiple file support
 */

@Component({
  selector: 'app-media-upload',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './media-upload.component.html',
  styleUrls: ['./media-upload.component.scss']
})
export class MediaUploadComponent implements OnInit, OnDestroy {
  @Input() config: IMediaUploadConfig = {
    maxFileSize: MediaService.MAX_FILE_SIZE,
    compressionEnabled: true,
    compressionQuality: 0.8
  };
  
  @Input() allowMultiple = true;
  @Input() showPreview = true;
  @Input() autoUpload = false;
  
  @Output() filesSelected = new EventEmitter<File[]>();
  @Output() uploadComplete = new EventEmitter<Media[]>();
  @Output() uploadError = new EventEmitter<string>();

  // Signals for reactive state
  isDragging = signal(false);
  selectedFiles = signal<File[]>([]);
  uploadItems = signal<FileUploadItem[]>([]);
  isUploading = signal(false);

  private destroy$ = new Subject<void>();

  constructor(public mediaService: MediaService) {}

  ngOnInit(): void {
    // Subscribe to upload queue changes
    this.mediaService.uploadQueue
      .pipe(takeUntil(this.destroy$))
      .subscribe(queue => {
        this.uploadItems.set(queue);
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ==================== FILE SELECTION ====================

  onFileInputChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.handleFiles(Array.from(input.files));
    }
  }

  // ==================== DRAG & DROP ====================

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging.set(true);
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging.set(false);
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging.set(false);

    if (event.dataTransfer?.files) {
      this.handleFiles(Array.from(event.dataTransfer.files));
    }
  }

  // ==================== FILE HANDLING ====================

  private handleFiles(files: File[]): void {
    if (!this.allowMultiple && files.length > 1) {
      files = [files[0]];
    }

    // Validate files
    const validationResults = this.mediaService.validateFiles(files, this.config);
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const error = validationResults.get(file.name);
      if (error) {
        errors.push(`${file.name}: ${error}`);
      } else {
        validFiles.push(file);
      }
    });

    if (errors.length > 0) {
      this.uploadError.emit(errors.join('\n'));
    }

    if (validFiles.length > 0) {
      this.selectedFiles.set([...this.selectedFiles(), ...validFiles]);
      this.filesSelected.emit(validFiles);

      if (this.autoUpload) {
        this.uploadFiles();
      }
    }
  }

  // ==================== UPLOAD ====================

  async uploadFiles(): Promise<void> {
    const files = this.selectedFiles();
    if (files.length === 0) return;

    this.isUploading.set(true);
    const uploadedMedia: Media[] = [];

    try {
      // Upload all files
      for (const file of files) {
        try {
          const result = await this.mediaService.uploadFile(file, this.config);
          if (result.success && result.data) {
            uploadedMedia.push(...result.data);
          }
        } catch (error: any) {
          this.uploadError.emit(error.message || 'Upload failed');
        }
      }
      
      // Emit complete event
      this.uploadComplete.emit(uploadedMedia);
      this.clearSelection();
    } finally {
      this.isUploading.set(false);
    }
  }

  // ==================== FILE MANAGEMENT ====================

  removeFile(index: number): void {
    const files = this.selectedFiles();
    files.splice(index, 1);
    this.selectedFiles.set([...files]);
  }

  clearSelection(): void {
    this.selectedFiles.set([]);
  }

  cancelUpload(uploadId: string): void {
    this.mediaService.cancelUpload(uploadId);
  }

  // ==================== UTILITY ====================

  getFilePreview(file: File): string {
    if (this.mediaService.isImageFile(file)) {
      return URL.createObjectURL(file);
    }
    return this.getFileIcon(file);
  }

  getFileIcon(file: File): string {
    const extension = this.mediaService.extractExtension(file.name);
    const iconMap: Record<string, string> = {
      'pdf': '📄',
      'doc': '📝',
      'docx': '📝',
      'xls': '📊',
      'xlsx': '📊',
      'ppt': '📊',
      'pptx': '📊',
      'zip': '🗜️',
      'default': '📁'
    };
    return iconMap[extension.toLowerCase()] || iconMap['default'];
  }

  formatFileSize(bytes: number): string {
    return this.mediaService.formatBytes(bytes);
  }

  getUploadStatus(item: FileUploadItem): string {
    switch (item.status) {
      case 'pending':
        return 'Waiting...';
      case 'uploading':
        return `Uploading... ${item.progress}%`;
      case 'completed':
        return 'Completed';
      case 'failed':
        return `Failed: ${item.error || 'Unknown error'}`;
      case 'cancelled':
        return 'Cancelled';
      default:
        return '';
    }
  }
}
