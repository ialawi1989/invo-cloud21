import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject, takeUntil, debounceTime, distinctUntilChanged } from 'rxjs';

import { MediaService } from '../services/media.service';
import { Media, IMediaFilter } from '../models/media.model';

/**
 * Media Gallery Component
 * Displays media in a grid with filtering, sorting, and selection
 */

type ViewMode = 'grid' | 'list';
type SortBy = 'name' | 'date' | 'size' | 'type';
type SortOrder = 'asc' | 'desc';

@Component({
  selector: 'app-media-gallery',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './media-gallery.component.html',
  styleUrls: ['./media-gallery.component.scss']
})
export class MediaGalleryComponent implements OnInit, OnDestroy {
  @Input() selectionMode: 'single' | 'multiple' | 'none' = 'none';
  @Input() allowedTypes: string[] = [];
  @Input() showUploadButton = true;
  @Input() showFilters = true;

  @Output() mediaSelected = new EventEmitter<Media[]>();
  @Output() mediaDeleted = new EventEmitter<string[]>();
  @Output() uploadRequested = new EventEmitter<void>();

  // Signals
  mediaItems = signal<Media[]>([]);
  filteredItems = computed(() => this.applyFiltersAndSort());
  selectedItems = signal<Media[]>([]);
  isLoading = signal(false);
  viewMode = signal<ViewMode>('grid');

  // Filter and sort state
  searchQuery = signal('');
  contentTypeFilter = signal<string[]>([]);
  sortBy = signal<SortBy>('date');
  sortOrder = signal<SortOrder>('desc');

  // Search subject for debouncing
  private searchSubject = new Subject<string>();
  private destroy$ = new Subject<void>();

  constructor(private mediaService: MediaService) {}

  ngOnInit(): void {
    this.loadMedia();
    this.setupSearchDebounce();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.searchSubject.complete();
  }

  // ==================== DATA LOADING ====================

  private async loadMedia(): Promise<void> {
    this.isLoading.set(true);

    try {
      const media = await this.mediaService.getAllMedia();
      this.mediaItems.set(media);
    } catch (error) {
      console.error('Failed to load media:', error);
    } finally {
      this.isLoading.set(false);
    }
  }

  refreshMedia(): void {
    this.loadMedia();
  }

  // ==================== SEARCH ====================

  private setupSearchDebounce(): void {
    this.searchSubject
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe(query => {
        this.searchQuery.set(query);
      });
  }

  onSearchInput(event: Event): void {
    const query = (event.target as HTMLInputElement).value;
    this.searchSubject.next(query);
  }

  // ==================== FILTERING & SORTING ====================

  private applyFiltersAndSort(): Media[] {
    let items = [...this.mediaItems()];

    // Apply search filter
    const query = this.searchQuery().toLowerCase();
    if (query) {
      items = items.filter(item =>
        item.name.toLowerCase().includes(query) ||
        item.contentType.toLowerCase().includes(query)
      );
    }

    // Apply content type filter
    const contentTypes = this.contentTypeFilter();
    if (contentTypes.length > 0) {
      items = items.filter(item => contentTypes.includes(item.contentType));
    }

    // Apply allowed types filter
    if (this.allowedTypes.length > 0) {
      items = items.filter(item =>
        this.allowedTypes.includes(item.mediaType.extension) ||
        this.allowedTypes.includes(item.contentType)
      );
    }

    // Apply sorting
    items.sort((a, b) => {
      let comparison = 0;

      switch (this.sortBy()) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'date':
          comparison = new Date(a.createdDate).getTime() - new Date(b.createdDate).getTime();
          break;
        case 'size':
          comparison = a.getSize - b.getSize;
          break;
        case 'type':
          comparison = a.contentType.localeCompare(b.contentType);
          break;
      }

      return this.sortOrder() === 'asc' ? comparison : -comparison;
    });

    return items;
  }

  toggleContentTypeFilter(type: string): void {
    const current = this.contentTypeFilter();
    if (current.includes(type)) {
      this.contentTypeFilter.set(current.filter(t => t !== type));
    } else {
      this.contentTypeFilter.set([...current, type]);
    }
  }

  setSortBy(sortBy: SortBy): void {
    if (this.sortBy() === sortBy) {
      // Toggle order if same field
      this.sortOrder.set(this.sortOrder() === 'asc' ? 'desc' : 'asc');
    } else {
      this.sortBy.set(sortBy);
      this.sortOrder.set('desc');
    }
  }

  clearFilters(): void {
    this.searchQuery.set('');
    this.contentTypeFilter.set([]);
  }

  // ==================== SELECTION ====================

  toggleSelection(media: Media): void {
    if (this.selectionMode === 'none') return;

    const selected = this.selectedItems();
    const index = selected.findIndex(m => m.id === media.id);

    if (this.selectionMode === 'single') {
      this.selectedItems.set(index >= 0 ? [] : [media]);
    } else {
      if (index >= 0) {
        selected.splice(index, 1);
      } else {
        selected.push(media);
      }
      this.selectedItems.set([...selected]);
    }

    this.mediaSelected.emit(this.selectedItems());
  }

  isSelected(media: Media): boolean {
    return this.selectedItems().some(m => m.id === media.id);
  }

  selectAll(): void {
    if (this.selectionMode === 'multiple') {
      this.selectedItems.set([...this.filteredItems()]);
      this.mediaSelected.emit(this.selectedItems());
    }
  }

  deselectAll(): void {
    this.selectedItems.set([]);
    this.mediaSelected.emit([]);
  }

  // ==================== ACTIONS ====================

  async deleteSelected(): Promise<void> {
    const selected = this.selectedItems();
    if (selected.length === 0) return;

    const confirmed = confirm(`Delete ${selected.length} item(s)?`);
    if (!confirmed) return;

    const ids = selected.map(m => m.id!).filter(id => id !== null);

    try {
      const success = await this.mediaService.deleteMultipleMedia(ids);
      if (success) {
        this.mediaDeleted.emit(ids);
        this.refreshMedia();
        this.deselectAll();
      }
    } catch (error) {
      console.error('Failed to delete media:', error);
    }
  }

  downloadSelected(): void {
    const selected = this.selectedItems();
    selected.forEach(media => {
      if (media.isImage) {
        this.mediaService.downloadImage(media.url.original || '', media.name);
      } else {
        this.mediaService.downloadPDF(media);
      }
    });
  }

  // ==================== VIEW MODE ====================

  setViewMode(mode: ViewMode): void {
    this.viewMode.set(mode);
  }

  // ==================== UTILITY ====================

  getMediaThumbnail(media: Media): string {
    if (media.isImage) {
      return media.url.thumbnail || media.url.original || '';
    }
    return this.getFileTypeIcon(media.mediaType.extension);
  }

  getFileTypeIcon(extension: string): string {
    const iconMap: Record<string, string> = {
      'pdf': '📄',
      'doc': '📝',
      'docx': '📝',
      'xls': '📊',
      'xlsx': '📊',
      'ppt': '📊',
      'pptx': '📊',
      'zip': '🗜️',
      'mp4': '🎥',
      'mp3': '🎵',
      'default': '📁'
    };
    return iconMap[extension.toLowerCase()] || iconMap['default'];
  }

  getContentTypeLabel(type: string): string {
    const labels: Record<string, string> = {
      'image': 'Images',
      'docs': 'Documents',
      'video': 'Videos',
      'audio': 'Audio',
      'model': '3D Models'
    };
    return labels[type] || type;
  }

  getContentTypeCount(type: string): number {
    return this.mediaItems().filter(m => m.contentType === type).length;
  }
}
