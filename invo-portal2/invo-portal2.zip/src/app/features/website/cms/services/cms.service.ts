import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { Website } from '../../models/website.model';
import { CmsCollectionTemplate, CmsItemTemplate } from '../../models/cms-collection.model';

// ─── DTOs ─────────────────────────────────────────────────────────────────

export interface CmsListParams {
  page?:      number;
  pageSize?:  number;
  search?:    string;
  sortBy?:    string;
  sortDir?:   'asc' | 'desc';
  filters?:   Record<string, any>;
}

// ─── Service ──────────────────────────────────────────────────────────────

@Injectable({ providedIn: 'root' })
export class CmsService {
  private http    = inject(HttpClient);
  private baseUrl = environment.backendUrl;

  // ── Collections ─────────────────────────────────────────────────────────

  /** List all CmsCollection records for this company */
  async getCollections(): Promise<Website[]> {
    const res = await firstValueFrom(
      this.http.post<any>(`${this.baseUrl}company/getThemeByType`, { type: 'CmsCollection' })
    );
    return (res?.data?.list ?? []).map((item: any) => {
      const w = new Website();
      if (!item.type) item.type = 'CmsCollection';
      w.ParseJson(item);
      return w;
    });
  }

  /** Get a single collection by id */
  async getCollectionById(id: string): Promise<Website> {
    const res = await firstValueFrom(
      this.http.get<any>(`${this.baseUrl}company/getThemeById/${id}`)
    );
    const w = new Website();
    w.ParseJson(res.data);
    return w;
  }

  /** Create or update a collection */
  async saveCollection(collection: Website): Promise<any> {
    return firstValueFrom(
      this.http.post<any>(`${this.baseUrl}company/saveWebsiteTheme`, collection.toCleanJson())
    );
  }

  /** Save a raw payload directly (bypasses toCleanJson) */
  async saveRaw(payload: any): Promise<any> {
    return firstValueFrom(
      this.http.post<any>(`${this.baseUrl}company/saveWebsiteTheme`, payload)
    );
  }

  /** Delete a collection and all its items (cascade) */
  async deleteCollection(id: string): Promise<any> {
    return firstValueFrom(
      this.http.delete<any>(`${this.baseUrl}company/deleteCmsCollection/${id}`)
    );
  }

  // ── Items ────────────────────────────────────────────────────────────────

  /** List items belonging to a collection */
  async getItems(collectionId: string, params: CmsListParams = {}): Promise<{ list: Website[]; count: number }> {
    const body = {
      type: 'CmsItem',
      collectionId,
      page:     params.page     ?? 1,
      pageSize: params.pageSize ?? 50,
      search:   params.search   ?? '',
      sortBy:   params.sortBy   ?? '',
      sortDir:  params.sortDir  ?? 'asc',
      filters:  params.filters  ?? {},
    };
    const res = await firstValueFrom(
      this.http.post<any>(`${this.baseUrl}company/getThemeByType`, body)
    );
    const list = (res?.data?.list ?? []).map((item: any) => {
      const w = new Website();
      // API response items don't include 'type', so set it before ParseJson
      // so Website.ParseJson correctly hydrates template as CmsItemTemplate
      if (!item.type) item.type = 'CmsItem';
      w.ParseJson(item);
      return w;
    });
    return { list, count: res?.data?.count ?? list.length };
  }

  /** Get single item */
  async getItemById(id: string): Promise<Website> {
    const res = await firstValueFrom(
      this.http.get<any>(`${this.baseUrl}company/getThemeById/${id}`)
    );
    const w = new Website();
    w.ParseJson(res.data);
    return w;
  }

  /** Create or update an item */
  async saveItem(item: Website): Promise<any> {
    return firstValueFrom(
      this.http.post<any>(`${this.baseUrl}company/saveWebsiteTheme`, item.toCleanJson())
    );
  }

  /** Delete an item */
  async deleteItem(id: string): Promise<any> {
    return firstValueFrom(
      this.http.delete<any>(`${this.baseUrl}company/deletTheme/${id}`)
    );
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  /** Build a new unsaved Website of type CmsCollection */
  buildNewCollection(displayName: string): Website {
    const w = new Website();
    w.type = 'CmsCollection';
    w.name = displayName;
    const tpl = new CmsCollectionTemplate();
    tpl.displayName = displayName;
    tpl.slug        = displayName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    w.template      = tpl;
    return w;
  }

  /** Build a new unsaved Website of type CmsItem */
  buildNewItem(collectionId: string, data: Record<string, any> = {}): Website {
    const w = new Website();
    w.type = 'CmsItem';
    w.name = data['title'] ?? 'New Item';
    const tpl = new CmsItemTemplate();
    tpl.collectionId = collectionId;
    tpl.data         = data;
    w.template       = tpl;
    return w;
  }
}
