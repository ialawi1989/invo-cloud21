// ─── Field Types ─────────────────────────────────────────────────────────────

export type CmsFieldType =
  // Essentials
  | 'text'
  | 'long-text'
  | 'rich-text'
  | 'rich-content'
  | 'url'
  | 'email'
  | 'number'
  | 'tags'
  | 'boolean'
  | 'reference'
  | 'multi-reference'
  | 'color'
  | 'choice'
  | 'multi-choice'
  // Media
  | 'image'
  | 'media-gallery'
  | 'video'
  | 'audio'
  | 'document'
  | 'multi-document'
  // Time and location
  | 'date'
  | 'datetime'
  | 'time'
  | 'address';

export class CmsFieldOption {
  label = '';
  value = '';
  ParseJson(json: any): void {
    for (const key in json) {
      if (key in this) this[key as keyof typeof this] = json[key];
    }
  }
}

export class CmsField {
  id         = '';
  name       = '';
  key        = '';
  type: CmsFieldType = 'text';
  required   = false;
  isSystem   = false;
  isVisible  = true;
  options: CmsFieldOption[] = [];
  referenceCollectionId = '';

  ParseJson(json: any): void {
    for (const key in json) {
      if (key === 'options') {
        this.options = (json[key] || []).map((o: any) => {
          const opt = new CmsFieldOption();
          opt.ParseJson(o);
          return opt;
        });
      } else if (key in this) {
        this[key as keyof typeof this] = json[key];
      }
    }
  }
}

export class CmsCollectionView {
  id      = '';
  name    = '';
  filters: { fieldKey: string; operator: string; value: any }[] = [];
  sortBy  = '';
  sortDir: 'asc' | 'desc' = 'asc';

  ParseJson(json: any): void {
    for (const key in json) {
      if (key in this) this[key as keyof typeof this] = json[key];
    }
  }
}

export class CmsCollectionTemplate {
  displayName  = '';
  slug         = '';
  description  = '';
  icon         = '';
  color        = '#32acc1';
  fields       : CmsField[] = [];
  views        : CmsCollectionView[] = [];

  // ── Collection settings ──
  controlVisibility  = false;
  defaultVisibility: 'visible' | 'hidden' = 'visible';
  hideTableLayout    = false;

  // ── Permissions & privacy ──
  permMode:     'show' | 'collect' | 'advanced' = 'show';
  viewAudience: 'everyone' | 'members' | 'collaborators' = 'everyone';
  addAudience:  'everyone' | 'members' | 'collaborators' = 'everyone';
  permRows: { role: string; tooltip: string; view: boolean; add: boolean; update: boolean; del: boolean; locked?: boolean }[] = [];

  constructor() {
    const titleField       = new CmsField();
    titleField.id          = 'sys-title';
    titleField.name        = 'Title';
    titleField.key         = 'title';
    titleField.type        = 'text';
    titleField.required    = true;
    titleField.isSystem    = true;

    const slugField        = new CmsField();
    slugField.id           = 'sys-slug';
    slugField.name         = 'Slug';
    slugField.key          = 'slug';
    slugField.type         = 'url';
    slugField.required     = true;
    slugField.isSystem     = true;

    const publishedField   = new CmsField();
    publishedField.id      = 'sys-published';
    publishedField.name    = 'Published';
    publishedField.key     = 'published';
    publishedField.type    = 'boolean';
    publishedField.isSystem = true;

    this.fields = [titleField, slugField, publishedField];

    const defaultView      = new CmsCollectionView();
    defaultView.id         = 'default';
    defaultView.name       = 'Default view';
    this.views             = [defaultView];
  }

  ParseJson(json: any): void {
    for (const key in json) {
      if (key === 'fields') {
        this.fields = (json[key] || []).map((f: any) => {
          const field = new CmsField();
          field.ParseJson(f);
          return field;
        });
      } else if (key === 'views') {
        this.views = (json[key] || []).map((v: any) => {
          const view = new CmsCollectionView();
          view.ParseJson(v);
          return view;
        });
      } else if (key in this) {
        this[key as keyof typeof this] = json[key];
      }
    }
  }

  /** Serialize preserving false/0/'' values that cleanForDb would strip. */
  toJson(): any {
    return {
      displayName:        this.displayName,
      slug:               this.slug,
      description:        this.description,
      icon:               this.icon,
      color:              this.color,
      fields:             this.fields,
      views:              this.views,
      controlVisibility:  this.controlVisibility,
      defaultVisibility:  this.defaultVisibility,
      hideTableLayout:    this.hideTableLayout,
      permMode:           this.permMode,
      viewAudience:       this.viewAudience,
      addAudience:        this.addAudience,
      permRows:           this.permRows,
    };
  }
}

// ─── CmsItemTemplate ──────────────────────────────────────────────────────────
// Uses a custom toJson() instead of cleanForDb so that data values
// (empty strings, false, 0) are NEVER stripped.

export class CmsItemTemplate {
  collectionId = '';
  index        = 0;
  data: Record<string, any> = {};
  status: 'published' | 'draft' = 'draft';

  ParseJson(json: any): void {
    for (const key in json) {
      if (key in this) this[key as keyof typeof this] = json[key];
    }
  }

  // Called directly instead of cleanForDb — preserves all data values
  toJson(): any {
    return {
      collectionId: this.collectionId,
      index:        this.index,
      status:       this.status,
      data:         { ...this.data },  // always include all fields as-is
    };
  }
}
