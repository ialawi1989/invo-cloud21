import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { CmsService } from '../../services/cms.service';
import { ModalService } from '../../../../../shared/modal/modal.service';
import { Website } from '../../../models/website.model';
import { CmsField } from '../../../models/cms-collection.model';
import { ManageFieldsModalComponent } from '../../components/manage-fields-modal.component';

@Component({
  selector: 'app-cms-item',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  styles: [`
    :host { display:block; min-height:100vh; background:#f4f5f7; }
    .page-header { background:#fff; border-bottom:1px solid #e5e8ed; padding:0 40px; height:56px; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:10; }
    .breadcrumb { display:flex; align-items:center; gap:6px; font-size:13px; }
    .bc-link { color:#6b7280; text-decoration:none; cursor:pointer; }
    .bc-link:hover { color:#32acc1; }
    .bc-sep { color:#d1d5db; font-size:12px; }
    .bc-cur { color:#1b2533; font-weight:500; }
    .header-actions { display:flex; align-items:center; gap:10px; }
    .btn { display:inline-flex; align-items:center; gap:6px; height:36px; padding:0 20px; border-radius:100px; font-size:13px; font-weight:500; cursor:pointer; font-family:inherit; transition:.15s; }
    .btn-cancel { background:#fff; border:1px solid #dfe3eb; color:#374151; }
    .btn-cancel:hover { background:#f8fafc; }
    .btn-save { background:#32acc1; border:none; color:#fff; }
    .btn-save:hover { background:#2b95a8; }
    .btn-save:disabled { opacity:.6; cursor:not-allowed; }
    .btn-del { background:transparent; border:none; width:36px; height:36px; padding:0; display:flex; align-items:center; justify-content:center; border-radius:50%; color:#9ca3af; cursor:pointer; }
    .btn-del:hover { background:#fef2f2; color:#e53e3e; }
    .item-title-bar { padding:24px 40px 0; }
    .item-title { font-size:26px; font-weight:700; color:#1b2533; margin:0; }
    .content-wrap { display:flex; justify-content:center; padding:24px 40px 60px; }
    .card { background:#fff; border:1px solid #e5e8ed; border-radius:10px; width:100%; max-width:680px; overflow:hidden; }
    .card-head { display:flex; align-items:center; justify-content:space-between; padding:16px 24px; border-bottom:1px solid #f0f2f5; }
    .card-title { font-size:14px; font-weight:600; color:#1b2533; }
    .mf-btn { font-size:13px; color:#32acc1; background:none; border:none; cursor:pointer; font-family:inherit; }
    .mf-btn:hover { text-decoration:underline; }
    .fields-body { padding:24px; }
    .field-group { margin-bottom:22px; }
    .field-label { font-size:13px; font-weight:500; color:#374151; margin-bottom:7px; display:block; }
    .field-hint { font-size:11px; color:#9ca3af; margin-top:5px; }
    .field-input { width:100%; height:42px; border:1px solid #dfe3eb; border-radius:6px; padding:0 14px; font-size:14px; font-family:inherit; color:#1b2533; outline:none; background:#fff; box-sizing:border-box; transition:.12s; }
    .field-input:focus { border-color:#32acc1; box-shadow:0 0 0 3px rgba(50,172,193,.1); }
    .field-textarea { width:100%; min-height:100px; border:1px solid #dfe3eb; border-radius:6px; padding:12px 14px; font-size:14px; font-family:inherit; color:#1b2533; outline:none; background:#fff; box-sizing:border-box; resize:vertical; transition:.12s; }
    .field-textarea:focus { border-color:#32acc1; box-shadow:0 0 0 3px rgba(50,172,193,.1); }
    .field-select { width:100%; height:42px; border:1px solid #dfe3eb; border-radius:6px; padding:0 14px; font-size:14px; font-family:inherit; color:#1b2533; outline:none; background:#fff; box-sizing:border-box; }
    .url-row { display:flex; gap:8px; align-items:center; }
    .url-display { flex:1; height:42px; border:1px solid #f0f2f5; border-radius:6px; padding:0 14px; font-size:13px; font-family:monospace; color:#6b7280; background:#f8fafc; display:flex; align-items:center; overflow:hidden; white-space:nowrap; text-overflow:ellipsis; min-width:0; }
    .url-edit { height:34px; padding:0 14px; border-radius:100px; border:1px solid #dfe3eb; background:#fff; font-size:13px; color:#374151; cursor:pointer; font-family:inherit; white-space:nowrap; }
    .url-edit:hover { background:#f8fafc; }
    .toggle-row { display:flex; align-items:center; gap:12px; }
    .toggle { width:42px; height:24px; border-radius:12px; cursor:pointer; transition:.2s; position:relative; flex-shrink:0; }
    .toggle-knob { position:absolute; top:3px; width:18px; height:18px; border-radius:50%; background:#fff; transition:.2s; box-shadow:0 1px 4px rgba(0,0,0,.2); }
    .toggle-lbl { font-size:14px; color:#374151; }
    .img-zone { border:1.5px dashed #dfe3eb; border-radius:8px; min-height:140px; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; cursor:pointer; transition:.15s; background:#fafbfc; padding:20px; }
    .img-zone:hover { border-color:#32acc1; background:#f0fdfb; }
    .img-zone img { max-width:100%; max-height:180px; border-radius:6px; object-fit:cover; }
    .img-zone-label { font-size:13px; color:#9ca3af; }
    .img-actions { display:flex; gap:8px; margin-top:8px; }
    .img-btn { height:30px; padding:0 16px; border-radius:100px; font-size:13px; font-weight:500; cursor:pointer; font-family:inherit; }
    .img-btn-up { border:1px solid #b2e4ed; background:#e6f7f9; color:#0a8da0; }
    .img-btn-up:hover { background:#d0f0f6; }
    .img-btn-del { border:1px solid #fecaca; background:#fef2f2; color:#e53e3e; }
    .add-field-row { display:flex; align-items:center; gap:8px; padding:16px 24px; border-top:1px solid #f0f2f5; }
    .add-field-btn { display:inline-flex; align-items:center; gap:7px; font-size:13px; color:#32acc1; background:none; border:none; cursor:pointer; font-family:inherit; font-weight:500; }
    .add-field-btn:hover { text-decoration:underline; }
    .spin { width:14px; height:14px; border-radius:50%; border:2px solid rgba(255,255,255,.3); border-top-color:#fff; animation:spin .6s linear infinite; display:inline-block; }
    .loading { display:flex; align-items:center; justify-content:center; gap:12px; padding:100px; color:#9ca3af; font-size:14px; }
    .spin-gray { width:18px; height:18px; border-radius:50%; border:2.5px solid #e5e8ed; border-top-color:#32acc1; animation:spin .6s linear infinite; display:inline-block; }
    @keyframes spin { to { transform:rotate(360deg); } }
  `],
  template: `
    <!-- Header -->
    <div class="page-header">
      <div class="breadcrumb">
        <a class="bc-link" routerLink="/website/cms">CMS</a>
        <span class="bc-sep">›</span>
        <a class="bc-link" [routerLink]="['/website/cms', collectionId]">{{ collectionName() }}</a>
        <span class="bc-sep">›</span>
        <span class="bc-cur">{{ isNew ? 'New Item' : (formData['title'] || 'Edit Item') }}</span>
      </div>
      <div class="header-actions">
        <button class="btn-del" title="Delete item" (click)="deleteItem()" *ngIf="!isNew">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>
        </button>
        <button class="btn btn-cancel" [routerLink]="['/website/cms', collectionId]">Cancel</button>
        <button class="btn btn-save" (click)="save()" [disabled]="saving()">
          @if (saving()) { <span class="spin"></span> }
          Save
        </button>
      </div>
    </div>

    @if (loading()) {
      <div class="loading"><span class="spin-gray"></span> Loading...</div>
    } @else {
      <!-- Item title -->
      <div class="item-title-bar">
        <h1 class="item-title">{{ isNew ? 'New Item' : (formData['title'] || 'Edit Item') }}</h1>
      </div>

      <div class="content-wrap">
        <div class="card">
          <div class="card-head">
            <span class="card-title">Item content</span>
            <button class="mf-btn" (click)="openManageFields()">Manage Fields</button>
          </div>

          <div class="fields-body">
            @for (field of fields(); track field.id) {
              <div class="field-group">
                <label class="field-label">
                  {{ field.name }}
                  @if (field.required) { <span style="color:#e53e3e">*</span> }
                </label>

                @switch (field.type) {
                  @case ('url') {
                    <div class="url-row">
                      <div class="url-display">
                        {{ formData[field.key] || ('/' + (formData['title'] || '').toLowerCase().replace(/\s+/g, '-')) }}
                      </div>
                      <button class="url-edit">Edit URL</button>
                    </div>
                    @if (field.key === 'slug') {
                      <div class="field-hint">
                        {{ baseUrl }}/items/<strong>{{ (formData['title'] || '').toLowerCase().replace(/\s+/g, '-') || '...' }}</strong>
                      </div>
                    }
                  }
                  @case ('long-text') {
                    <textarea class="field-textarea" [(ngModel)]="formData[field.key]"
                              [placeholder]="'Enter ' + field.name"></textarea>
                  }
                  @case ('boolean') {
                    <div class="toggle-row">
                      <div class="toggle"
                           [style.background]="formData[field.key] ? '#32acc1' : '#dfe3eb'"
                           (click)="formData[field.key] = !formData[field.key]">
                        <div class="toggle-knob" [style.left]="formData[field.key] ? '21px' : '3px'"></div>
                      </div>
                      <span class="toggle-lbl">{{ formData[field.key] ? 'Enabled' : 'Disabled' }}</span>
                    </div>
                  }
                  @case ('choice') {
                    <select class="field-select" [(ngModel)]="formData[field.key]">
                      <option value="">— Select —</option>
                      @for (opt of field.options; track opt.value) {
                        <option [value]="opt.value">{{ opt.label }}</option>
                      }
                    </select>
                  }
                  @case ('image') {
                    <div>
                      <div class="img-zone">
                        @if (formData[field.key]?.url) {
                          <img [src]="formData[field.key].url"/>
                        } @else {
                          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#c4c9d4" stroke-width="1.2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                          <span class="img-zone-label">Click to upload image</span>
                        }
                      </div>
                      <div class="img-actions">
                        <button class="img-btn img-btn-up">{{ formData[field.key]?.url ? 'Change' : 'Upload' }}</button>
                        @if (formData[field.key]?.url) {
                          <button class="img-btn img-btn-del" (click)="formData[field.key]=null">Remove</button>
                        }
                      </div>
                    </div>
                  }
                  @case ('number') {
                    <input type="number" class="field-input" [(ngModel)]="formData[field.key]"
                           [placeholder]="'Enter ' + field.name"/>
                  }
                  @case ('date') {
                    <input type="date" class="field-input" [(ngModel)]="formData[field.key]"/>
                  }
                  @default {
                    <input type="text" class="field-input" [(ngModel)]="formData[field.key]"
                           [placeholder]="'Enter ' + field.name"
                           (ngModelChange)="field.key==='title' && onTitleChange($event)"/>
                  }
                }
              </div>
            }
          </div>

          <div class="add-field-row">
            <button class="add-field-btn" (click)="openManageFields()">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              Add Field
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class CmsItemPageComponent implements OnInit {
  private route    = inject(ActivatedRoute);
  private router   = inject(Router);
  private cms      = inject(CmsService);
  private modalSvc = inject(ModalService);

  collectionId   = '';
  itemId         = '';
  isNew          = false;
  collectionName = signal('Items');
  fields         = signal<CmsField[]>([]);
  loading        = signal(true);
  saving         = signal(false);
  formData: Record<string, any> = {};
  baseUrl        = window.location.hostname;

  private collection: Website | null = null;
  private item:       Website | null = null;

  async ngOnInit(): Promise<void> {
    this.collectionId = this.route.snapshot.paramMap.get('collectionId') ?? '';
    this.itemId       = this.route.snapshot.paramMap.get('itemId') ?? '';
    this.isNew        = !this.itemId || this.itemId === 'new';

    await this.loadCollection();
    if (!this.isNew) await this.loadItem();
    this.loading.set(false);
  }

  async loadCollection(): Promise<void> {
    this.collection = await this.cms.getCollectionById(this.collectionId);
    this.collectionName.set(this.collection?.template?.displayName ?? 'Items');
    this.fields.set(this.collection?.template?.fields ?? []);
    // init boolean defaults
    this.fields().filter((f: CmsField) => f.type === 'boolean').forEach((f: CmsField) => {
      if (!(f.key in this.formData)) this.formData[f.key] = false;
    });
  }

  async loadItem(): Promise<void> {
    this.item = await this.cms.getItemById(this.itemId);
    this.formData = { ...(this.item?.template?.data ?? {}) };
  }

  onTitleChange(value: string): void {
    const slugField = this.fields().find((f: CmsField) => f.type === 'url');
    if (slugField) {
      this.formData[slugField.key] = '/' + value.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    }
  }

  async save(): Promise<void> {
    this.saving.set(true);
    try {
      const website        = this.item ?? this.cms.buildNewItem(this.collectionId, {});
      website.template.data         = { ...this.formData };
      website.template.collectionId = this.collectionId;
      website.template.status       = website.template.status || 'draft';
      website.name                  = this.formData['title'] ?? 'Untitled';
      const res = await this.cms.saveItem(website);
      this.router.navigate(['/website/cms', this.collectionId]);
    } finally {
      this.saving.set(false);
    }
  }

  async deleteItem(): Promise<void> {
    if (!confirm('Delete this item?')) return;
    await this.cms.deleteItem(this.itemId);
    this.router.navigate(['/website/cms', this.collectionId]);
  }

  openManageFields(): void {
    if (!this.collection) return;
    const ref = this.modalSvc.open(ManageFieldsModalComponent, {
      size: 'md', closeOnBackdrop: false, data: { collection: this.collection }
    });
    ref.afterClosed().then((result: any) => {
      if (result?.saved) this.loadCollection();
    });
  }
}
