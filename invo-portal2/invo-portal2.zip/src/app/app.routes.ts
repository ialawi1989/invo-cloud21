import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { guestGuard } from './core/guards/guest.guard';

export const routes: Routes = [
  // ── Public (blocked for authenticated users) ─────────────────────────────
  {
    path: 'login',
    canActivate: [guestGuard],
    loadComponent: () =>
      import('./features/login/login.component').then(m => m.LoginComponent),
  },

  // ── Error pages ──────────────────────────────────────────────────────────
  {
    path: '403',
    loadComponent: () =>
      import('./shared/pages/forbidden.component').then(m => m.ForbiddenComponent),
  },
  {
    path: 'feature-unavailable',
    loadComponent: () =>
      import('./shared/pages/feature-unavailable.component').then(m => m.FeatureUnavailableComponent),
  },

  // ── Protected (requires login) ───────────────────────────────────────────
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./core/layout/main-layout.component').then(m => m.MainLayoutComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent),
      },
      {
        path: 'settings',
        loadComponent: () =>
          import('./features/settings/settings.component').then(m => m.SettingsComponent),
      },
      // ── Website CMS ───────────────────────────────────────────────────────
      {
        path: 'website/cms',
        loadComponent: () =>
          import('./features/website/cms/pages/cms-list/cms-list.component').then(m => m.CmsListComponent),
      },
      {
        path: 'website/cms/:id',
        loadComponent: () =>
          import('./features/website/cms/pages/cms-collection/cms-collection.component').then(m => m.CmsCollectionComponent),
      },

      {
        path: 'website/cms/:collectionId/item/:itemId',
        loadComponent: () =>
          import('./features/website/cms/pages/cms-item/cms-item.component').then(m => m.CmsItemPageComponent),
      },
      {
        path: 'media',
        loadChildren: () => import('./features/media').then(m => m.MEDIA_ROUTES)
      }
      // ── Add features here as you build them ──────────────────────────────
    ],
  },

  {
    path: '**',
    loadComponent: () =>
      import('./shared/pages/not-found.component').then(m => m.NotFoundComponent),
  },
];
