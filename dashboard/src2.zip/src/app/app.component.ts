import { Component } from '@angular/core';
import { CustomizerComponent } from './components/customizer/customizer.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CustomizerComponent],
  template: `<app-customizer></app-customizer>`,
  styles: [`
    :host {
      display: block;
      height: 100vh;
    }
  `]
})
export class AppComponent {}
