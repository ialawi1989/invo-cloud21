// Component Types
export type ComponentType = 
  | 'hero' 
  | 'features' 
  | 'testimonials' 
  | 'cta' 
  | 'pricing' 
  | 'gallery' 
  | 'faq' 
  | 'contact' 
  | 'stats'
  | 'team'
  | 'newsletter';

export interface PageComponent {
  id: string;
  type: ComponentType;
  settings: Record<string, any>;
  order: number;
}

export interface ComponentDefinition {
  type: ComponentType;
  name: string;
  icon: string;
  description: string;
  defaultSettings: Record<string, any>;
  settingsSchema: SettingField[];
}

export interface SettingField {
  key: string;
  label: string;
  type: 'text' | 'textarea' | 'color' | 'number' | 'select' | 'toggle' | 'range';
  options?: { value: string; label: string }[];
  min?: number;
  max?: number;
  step?: number;
}

// Global Settings
export interface GlobalSettings {
  // Colors
  headerBgColor: string;
  headerTextColor: string;
  bodyBgColor: string;
  bodyTextColor: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  
  // Typography
  fontFamily: string;
  headingFontFamily: string;
  baseFontSize: number;
  headingFontSize: number;
  lineHeight: number;
  fontWeight: number;
  
  // Layout
  containerWidth: number;
  headerHeight: number;
  sectionPadding: number;
  borderRadius: number;
  
  // Site Info
  siteTitle: string;
  siteTagline: string;
  footerText: string;
  
  // Features
  showHeader: boolean;
  showFooter: boolean;
  stickyHeader: boolean;
}

export interface PageData {
  globalSettings: GlobalSettings;
  components: PageComponent[];
}

export const DEFAULT_GLOBAL_SETTINGS: GlobalSettings = {
  headerBgColor: '#ffffff',
  headerTextColor: '#1f2937',
  bodyBgColor: '#ffffff',
  bodyTextColor: '#374151',
  primaryColor: '#6366f1',
  secondaryColor: '#8b5cf6',
  accentColor: '#06b6d4',
  
  fontFamily: 'Inter',
  headingFontFamily: 'Inter',
  baseFontSize: 16,
  headingFontSize: 48,
  lineHeight: 1.6,
  fontWeight: 400,
  
  containerWidth: 1200,
  headerHeight: 70,
  sectionPadding: 80,
  borderRadius: 12,
  
  siteTitle: 'My Website',
  siteTagline: 'Building amazing experiences',
  footerText: '© 2024 My Website. All rights reserved.',
  
  showHeader: true,
  showFooter: true,
  stickyHeader: true
};

// Component Library
export const COMPONENT_LIBRARY: ComponentDefinition[] = [
  {
    type: 'hero',
    name: 'Hero Section',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>',
    description: 'Large banner with title, subtitle and CTA',
    defaultSettings: {
      title: 'Welcome to Our Platform',
      subtitle: 'Create stunning websites with our powerful tools',
      buttonText: 'Get Started',
      buttonLink: '#',
      showSecondaryButton: true,
      secondaryButtonText: 'Learn More',
      backgroundStyle: 'gradient',
      alignment: 'left'
    },
    settingsSchema: [
      { key: 'title', label: 'Title', type: 'text' },
      { key: 'subtitle', label: 'Subtitle', type: 'textarea' },
      { key: 'buttonText', label: 'Button Text', type: 'text' },
      { key: 'buttonLink', label: 'Button Link', type: 'text' },
      { key: 'showSecondaryButton', label: 'Show Secondary Button', type: 'toggle' },
      { key: 'secondaryButtonText', label: 'Secondary Button Text', type: 'text' },
      { key: 'alignment', label: 'Alignment', type: 'select', options: [
        { value: 'left', label: 'Left' },
        { value: 'center', label: 'Center' },
        { value: 'right', label: 'Right' }
      ]},
      { key: 'backgroundStyle', label: 'Background', type: 'select', options: [
        { value: 'gradient', label: 'Gradient' },
        { value: 'solid', label: 'Solid' },
        { value: 'image', label: 'Image' }
      ]}
    ]
  },
  {
    type: 'features',
    name: 'Features Grid',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>',
    description: 'Display features in a grid layout',
    defaultSettings: {
      title: 'Our Features',
      subtitle: 'Everything you need to succeed',
      columns: 3,
      features: [
        { icon: 'zap', title: 'Lightning Fast', description: 'Optimized for speed and performance' },
        { icon: 'shield', title: 'Secure', description: 'Enterprise-grade security built-in' },
        { icon: 'code', title: 'Developer Friendly', description: 'Clean code and great documentation' },
        { icon: 'globe', title: 'Global CDN', description: 'Delivered from edge locations worldwide' },
        { icon: 'clock', title: '24/7 Support', description: 'Round the clock customer support' },
        { icon: 'trending-up', title: 'Analytics', description: 'Detailed insights and reporting' }
      ]
    },
    settingsSchema: [
      { key: 'title', label: 'Section Title', type: 'text' },
      { key: 'subtitle', label: 'Section Subtitle', type: 'text' },
      { key: 'columns', label: 'Columns', type: 'select', options: [
        { value: '2', label: '2 Columns' },
        { value: '3', label: '3 Columns' },
        { value: '4', label: '4 Columns' }
      ]}
    ]
  },
  {
    type: 'testimonials',
    name: 'Testimonials',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>',
    description: 'Customer testimonials and reviews',
    defaultSettings: {
      title: 'What Our Customers Say',
      subtitle: 'Trusted by thousands of happy customers',
      testimonials: [
        { name: 'Sarah Johnson', role: 'CEO, TechCorp', content: 'This platform transformed our business. Highly recommended!', avatar: '' },
        { name: 'Mike Chen', role: 'Developer', content: 'The best developer experience I have ever had. Amazing tools!', avatar: '' },
        { name: 'Emily Davis', role: 'Designer', content: 'Beautiful, intuitive, and powerful. Everything I need in one place.', avatar: '' }
      ],
      layout: 'grid'
    },
    settingsSchema: [
      { key: 'title', label: 'Section Title', type: 'text' },
      { key: 'subtitle', label: 'Section Subtitle', type: 'text' },
      { key: 'layout', label: 'Layout', type: 'select', options: [
        { value: 'grid', label: 'Grid' },
        { value: 'carousel', label: 'Carousel' }
      ]}
    ]
  },
  {
    type: 'cta',
    name: 'Call to Action',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
    description: 'Prominent call-to-action section',
    defaultSettings: {
      title: 'Ready to Get Started?',
      subtitle: 'Join thousands of satisfied customers today',
      buttonText: 'Start Free Trial',
      buttonLink: '#',
      style: 'gradient'
    },
    settingsSchema: [
      { key: 'title', label: 'Title', type: 'text' },
      { key: 'subtitle', label: 'Subtitle', type: 'text' },
      { key: 'buttonText', label: 'Button Text', type: 'text' },
      { key: 'buttonLink', label: 'Button Link', type: 'text' },
      { key: 'style', label: 'Style', type: 'select', options: [
        { value: 'gradient', label: 'Gradient Background' },
        { value: 'solid', label: 'Solid Background' },
        { value: 'outline', label: 'Outline' }
      ]}
    ]
  },
  {
    type: 'pricing',
    name: 'Pricing Table',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>',
    description: 'Pricing plans comparison',
    defaultSettings: {
      title: 'Simple, Transparent Pricing',
      subtitle: 'Choose the plan that works for you',
      plans: [
        { name: 'Starter', price: '9', period: 'month', features: ['5 Projects', '10GB Storage', 'Basic Support'], highlighted: false },
        { name: 'Pro', price: '29', period: 'month', features: ['Unlimited Projects', '100GB Storage', 'Priority Support', 'Advanced Analytics'], highlighted: true },
        { name: 'Enterprise', price: '99', period: 'month', features: ['Everything in Pro', 'Custom Integrations', 'Dedicated Account Manager', 'SLA'], highlighted: false }
      ]
    },
    settingsSchema: [
      { key: 'title', label: 'Section Title', type: 'text' },
      { key: 'subtitle', label: 'Section Subtitle', type: 'text' }
    ]
  },
  {
    type: 'stats',
    name: 'Statistics',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
    description: 'Key statistics and numbers',
    defaultSettings: {
      title: 'Our Impact',
      subtitle: 'Numbers that speak for themselves',
      stats: [
        { value: '10K+', label: 'Active Users' },
        { value: '99.9%', label: 'Uptime' },
        { value: '50M+', label: 'Requests/Day' },
        { value: '24/7', label: 'Support' }
      ],
      style: 'cards'
    },
    settingsSchema: [
      { key: 'title', label: 'Section Title', type: 'text' },
      { key: 'subtitle', label: 'Section Subtitle', type: 'text' },
      { key: 'style', label: 'Style', type: 'select', options: [
        { value: 'cards', label: 'Cards' },
        { value: 'inline', label: 'Inline' },
        { value: 'minimal', label: 'Minimal' }
      ]}
    ]
  },
  {
    type: 'faq',
    name: 'FAQ Section',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
    description: 'Frequently asked questions',
    defaultSettings: {
      title: 'Frequently Asked Questions',
      subtitle: 'Find answers to common questions',
      faqs: [
        { question: 'How do I get started?', answer: 'Simply sign up for an account and follow our quick start guide.' },
        { question: 'Is there a free trial?', answer: 'Yes! We offer a 14-day free trial with full access to all features.' },
        { question: 'Can I cancel anytime?', answer: 'Absolutely. You can cancel your subscription at any time with no penalties.' },
        { question: 'Do you offer support?', answer: 'We provide 24/7 support via chat, email, and phone for all plans.' }
      ]
    },
    settingsSchema: [
      { key: 'title', label: 'Section Title', type: 'text' },
      { key: 'subtitle', label: 'Section Subtitle', type: 'text' }
    ]
  },
  {
    type: 'contact',
    name: 'Contact Form',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
    description: 'Contact form with details',
    defaultSettings: {
      title: 'Get in Touch',
      subtitle: 'We would love to hear from you',
      email: 'hello@example.com',
      phone: '+1 (555) 123-4567',
      address: '123 Main St, City, Country',
      showMap: false
    },
    settingsSchema: [
      { key: 'title', label: 'Section Title', type: 'text' },
      { key: 'subtitle', label: 'Section Subtitle', type: 'text' },
      { key: 'email', label: 'Email', type: 'text' },
      { key: 'phone', label: 'Phone', type: 'text' },
      { key: 'address', label: 'Address', type: 'text' },
      { key: 'showMap', label: 'Show Map', type: 'toggle' }
    ]
  },
  {
    type: 'newsletter',
    name: 'Newsletter',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
    description: 'Email subscription form',
    defaultSettings: {
      title: 'Stay Updated',
      subtitle: 'Subscribe to our newsletter for the latest updates',
      buttonText: 'Subscribe',
      placeholder: 'Enter your email'
    },
    settingsSchema: [
      { key: 'title', label: 'Title', type: 'text' },
      { key: 'subtitle', label: 'Subtitle', type: 'text' },
      { key: 'buttonText', label: 'Button Text', type: 'text' },
      { key: 'placeholder', label: 'Placeholder', type: 'text' }
    ]
  },
  {
    type: 'gallery',
    name: 'Image Gallery',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
    description: 'Image gallery grid',
    defaultSettings: {
      title: 'Our Work',
      subtitle: 'Check out some of our recent projects',
      columns: 3,
      images: [
        { src: 'https://picsum.photos/400/300?random=1', alt: 'Project 1' },
        { src: 'https://picsum.photos/400/300?random=2', alt: 'Project 2' },
        { src: 'https://picsum.photos/400/300?random=3', alt: 'Project 3' },
        { src: 'https://picsum.photos/400/300?random=4', alt: 'Project 4' },
        { src: 'https://picsum.photos/400/300?random=5', alt: 'Project 5' },
        { src: 'https://picsum.photos/400/300?random=6', alt: 'Project 6' }
      ]
    },
    settingsSchema: [
      { key: 'title', label: 'Section Title', type: 'text' },
      { key: 'subtitle', label: 'Section Subtitle', type: 'text' },
      { key: 'columns', label: 'Columns', type: 'select', options: [
        { value: '2', label: '2 Columns' },
        { value: '3', label: '3 Columns' },
        { value: '4', label: '4 Columns' }
      ]}
    ]
  },
  {
    type: 'team',
    name: 'Team Section',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>',
    description: 'Team members showcase',
    defaultSettings: {
      title: 'Meet Our Team',
      subtitle: 'The people behind our success',
      members: [
        { name: 'John Doe', role: 'CEO & Founder', image: '', social: { twitter: '#', linkedin: '#' } },
        { name: 'Jane Smith', role: 'CTO', image: '', social: { twitter: '#', linkedin: '#' } },
        { name: 'Bob Wilson', role: 'Lead Designer', image: '', social: { twitter: '#', linkedin: '#' } },
        { name: 'Alice Brown', role: 'Marketing Director', image: '', social: { twitter: '#', linkedin: '#' } }
      ]
    },
    settingsSchema: [
      { key: 'title', label: 'Section Title', type: 'text' },
      { key: 'subtitle', label: 'Section Subtitle', type: 'text' }
    ]
  }
];

export interface MessagePayload {
  type: 'setting-change' | 'sync-all' | 'preview-ready' | 'element-click' | 'reset' | 'page-data';
  key?: string;
  value?: any;
  settings?: GlobalSettings;
  pageData?: PageData;
}

export interface HistoryState {
  pageData: PageData;
  timestamp: number;
}

export type DeviceType = 'desktop' | 'tablet' | 'mobile';

export const DEVICE_WIDTHS: Record<DeviceType, number> = {
  desktop: 100,
  tablet: 768,
  mobile: 375
};

export const FONT_OPTIONS = [
  { value: 'Inter', label: 'Inter' },
  { value: 'Roboto', label: 'Roboto' },
  { value: 'Open Sans', label: 'Open Sans' },
  { value: 'Lato', label: 'Lato' },
  { value: 'Poppins', label: 'Poppins' },
  { value: 'Montserrat', label: 'Montserrat' },
  { value: 'Playfair Display', label: 'Playfair Display' },
  { value: 'Merriweather', label: 'Merriweather' }
];

// Helper to generate unique IDs
export function generateId(): string {
  return Math.random().toString(36).substring(2, 11);
}
