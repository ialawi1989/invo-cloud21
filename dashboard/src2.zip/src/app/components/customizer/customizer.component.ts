import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ControlPanelComponent } from '../control-panel/control-panel.component';
import { PreviewFrameComponent } from '../preview-frame/preview-frame.component';
import { CustomizerService } from '../../services/customizer.service';
import { DeviceType } from '../../models/settings.model';

@Component({
  selector: 'app-customizer',
  standalone: true,
  imports: [CommonModule, ControlPanelComponent, PreviewFrameComponent],
  template: `
    <div class="customizer-layout">
      <!-- Header -->
      <header class="customizer-header">
        <div class="header-left">
          <div class="logo">
            <svg width="28" height="28" viewBox="0 0 32 32" fill="none">
              <rect width="32" height="32" rx="8" fill="#6366f1"/>
              <path d="M10 16L14 20L22 12" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span>Page Builder</span>
          </div>
        </div>
        
        <div class="header-center">
          <div class="device-buttons">
            <button 
              class="device-btn" 
              [class.active]="currentDevice() === 'desktop'"
              (click)="setDevice('desktop')"
              title="Desktop">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="2" y="3" width="20" height="14" rx="2"/>
                <line x1="8" y1="21" x2="16" y2="21"/>
                <line x1="12" y1="17" x2="12" y2="21"/>
              </svg>
            </button>
            <button 
              class="device-btn" 
              [class.active]="currentDevice() === 'tablet'"
              (click)="setDevice('tablet')"
              title="Tablet">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="4" y="2" width="16" height="20" rx="2"/>
                <line x1="12" y1="18" x2="12" y2="18"/>
              </svg>
            </button>
            <button 
              class="device-btn" 
              [class.active]="currentDevice() === 'mobile'"
              (click)="setDevice('mobile')"
              title="Mobile">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="5" y="2" width="14" height="20" rx="2"/>
                <line x1="12" y1="18" x2="12" y2="18"/>
              </svg>
            </button>
          </div>
        </div>
        
        <div class="header-right">
          <div class="history-buttons">
            <button 
              class="btn btn-icon btn-sm" 
              [disabled]="!customizer.canUndo()"
              (click)="customizer.undo()"
              title="Undo">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 7v6h6"/>
                <path d="M21 17a9 9 0 00-9-9 9 9 0 00-6 2.3L3 13"/>
              </svg>
            </button>
            <button 
              class="btn btn-icon btn-sm" 
              [disabled]="!customizer.canRedo()"
              (click)="customizer.redo()"
              title="Redo">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 7v6h-6"/>
                <path d="M3 17a9 9 0 019-9 9 9 0 016 2.3l3 2.7"/>
              </svg>
            </button>
          </div>
          
          <div class="status" [class.connected]="customizer.isPreviewReady()">
            <span class="status-dot"></span>
            {{ customizer.isPreviewReady() ? 'Live' : 'Connecting' }}
          </div>
          
          <button class="btn btn-secondary btn-sm" (click)="handleReset()">Reset</button>
          <button class="btn btn-primary btn-sm" (click)="handleSave()">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/>
              <polyline points="17,21 17,13 7,13 7,21"/>
              <polyline points="7,3 7,8 15,8"/>
            </svg>
            Save
          </button>
        </div>
      </header>
      
      <!-- Main Content -->
      <div class="customizer-main">
        <app-control-panel class="sidebar"></app-control-panel>
        
        <app-preview-frame 
          class="preview-area"
          [device]="currentDevice()">
        </app-preview-frame>
      </div>
      
      <!-- Toast -->
      @if (showToast()) {
        <div class="toast" [class]="toastType()">
          {{ toastMessage() }}
        </div>
      }
    </div>
  `,
  styles: [`
    .customizer-layout {
      display: flex;
      flex-direction: column;
      height: 100vh;
      overflow: hidden;
      background: var(--bg-gray-100);
    }
    
    .customizer-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: var(--header-height);
      padding: 0 16px;
      background: var(--bg-white);
      border-bottom: 1px solid var(--border-color);
      z-index: 100;
    }
    
    .header-left, .header-right {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    
    .header-center {
      display: flex;
      align-items: center;
    }
    
    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 16px;
      font-weight: 600;
      color: var(--text-primary);
    }
    
    .history-buttons {
      display: flex;
      gap: 4px;
    }
    
    .history-buttons button:disabled {
      opacity: 0.4;
      cursor: not-allowed;
    }
    
    .status {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px;
      background: var(--bg-gray-100);
      border-radius: 100px;
      font-size: 12px;
      font-weight: 500;
      color: var(--text-secondary);
    }
    
    .status-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--warning-color);
    }
    
    .status.connected .status-dot {
      background: var(--success-color);
    }
    
    .customizer-main {
      display: flex;
      flex: 1;
      overflow: hidden;
    }
    
    .sidebar {
      width: var(--sidebar-width);
      flex-shrink: 0;
      overflow: hidden;
      background: var(--bg-white);
      border-right: 1px solid var(--border-color);
      display: flex;
      flex-direction: column;
    }
    
    .preview-area {
      flex: 1;
      overflow: hidden;
    }
  `]
})
export class CustomizerComponent {
  currentDevice = signal<DeviceType>('desktop');
  showToast = signal<boolean>(false);
  toastMessage = signal<string>('');
  toastType = signal<'success' | 'error' | 'info'>('success');
  
  constructor(public customizer: CustomizerService) {}
  
  setDevice(device: DeviceType): void {
    this.currentDevice.set(device);
  }
  
  handleSave(): void {
    this.customizer.saveData();
    this.showNotification('Changes saved!', 'success');
  }
  
  handleReset(): void {
    if (confirm('Reset all changes? This cannot be undone.')) {
      this.customizer.resetToDefaults();
      this.showNotification('Reset complete', 'info');
    }
  }
  
  private showNotification(message: string, type: 'success' | 'error' | 'info'): void {
    this.toastMessage.set(message);
    this.toastType.set(type);
    this.showToast.set(true);
    setTimeout(() => this.showToast.set(false), 2500);
  }
}
