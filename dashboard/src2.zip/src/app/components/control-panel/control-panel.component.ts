import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CustomizerService } from '../../services/customizer.service';
import { 
  COMPONENT_LIBRARY, 
  ComponentDefinition,
  GlobalSettings,
  FONT_OPTIONS,
  PageComponent
} from '../../models/settings.model';

type TabType = 'components' | 'page' | 'settings';
type SettingsSection = 'colors' | 'typography' | 'layout' | 'site';

@Component({
  selector: 'app-control-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="control-panel">
      <!-- Tabs -->
      <div class="tabs">
        <button class="tab" [class.active]="activeTab() === 'components'" (click)="setTab('components')">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
          </svg>
          Add
        </button>
        <button class="tab" [class.active]="activeTab() === 'page'" (click)="setTab('page')">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
            <polyline points="14,2 14,8 20,8"/>
          </svg>
          Page
        </button>
        <button class="tab" [class.active]="activeTab() === 'settings'" (click)="setTab('settings')">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="3"/><path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
          </svg>
          Style
        </button>
      </div>
      
      <div class="tab-content">
        <!-- Components Library Tab -->
        @if (activeTab() === 'components') {
          <div class="panel-section">
            <div class="section-header">
              <h3>Component Library</h3>
              <span class="badge">{{ componentLibrary.length }}</span>
            </div>
            <p class="section-desc">Click to add components to your page</p>
            
            <div class="components-grid">
              @for (comp of componentLibrary; track comp.type) {
                <div class="component-card" (click)="addComponent(comp.type)">
                  <div class="icon" [innerHTML]="comp.icon"></div>
                  <div class="info">
                    <h4>{{ comp.name }}</h4>
                    <p>{{ comp.description }}</p>
                  </div>
                </div>
              }
            </div>
          </div>
        }
        
        <!-- Page Structure Tab -->
        @if (activeTab() === 'page') {
          <div class="panel-section">
            <div class="section-header">
              <h3>Page Structure</h3>
              <span class="badge">{{ components().length }}</span>
            </div>
            
            @if (components().length === 0) {
              <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                  <rect x="3" y="3" width="18" height="18" rx="2"/>
                  <line x1="12" y1="8" x2="12" y2="16"/>
                  <line x1="8" y1="12" x2="16" y2="12"/>
                </svg>
                <h3>No components yet</h3>
                <p>Add components from the library</p>
              </div>
            } @else {
              <div class="page-components">
                @for (comp of components(); track comp.id; let i = $index) {
                  <div 
                    class="page-component" 
                    [class.selected]="selectedComponentId() === comp.id"
                    (click)="selectComponent(comp.id)">
                    <span class="drag-handle">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
                        <circle cx="9" cy="6" r="2"/><circle cx="15" cy="6" r="2"/>
                        <circle cx="9" cy="12" r="2"/><circle cx="15" cy="12" r="2"/>
                        <circle cx="9" cy="18" r="2"/><circle cx="15" cy="18" r="2"/>
                      </svg>
                    </span>
                    <span class="name">{{ getComponentName(comp.type) }}</span>
                    <div class="actions">
                      <button class="btn btn-ghost btn-sm" (click)="moveComponent(comp.id, 'up', $event)" [disabled]="i === 0">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <polyline points="18,15 12,9 6,15"/>
                        </svg>
                      </button>
                      <button class="btn btn-ghost btn-sm" (click)="moveComponent(comp.id, 'down', $event)" [disabled]="i === components().length - 1">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <polyline points="6,9 12,15 18,9"/>
                        </svg>
                      </button>
                      <button class="btn btn-ghost btn-sm" (click)="duplicateComponent(comp.id, $event)">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <rect x="9" y="9" width="13" height="13" rx="2"/>
                          <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
                        </svg>
                      </button>
                      <button class="btn btn-ghost btn-sm" (click)="removeComponent(comp.id, $event)">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <polyline points="3,6 5,6 21,6"/>
                          <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                        </svg>
                      </button>
                    </div>
                  </div>
                }
              </div>
            }
            
            <!-- Component Settings -->
            @if (selectedComponent()) {
              <div class="divider"></div>
              <div class="section-header">
                <h3>{{ getComponentName(selectedComponent()!.type) }} Settings</h3>
              </div>
              <div class="component-settings">
                @for (field of getComponentSchema(selectedComponent()!.type); track field.key) {
                  <div class="control-group">
                    <label>{{ field.label }}</label>
                    @switch (field.type) {
                      @case ('text') {
                        <input type="text" 
                               [value]="selectedComponent()!.settings[field.key]"
                               (input)="onComponentSettingChange(field.key, $event)">
                      }
                      @case ('textarea') {
                        <textarea rows="2"
                                  [value]="selectedComponent()!.settings[field.key]"
                                  (input)="onComponentSettingChange(field.key, $event)"></textarea>
                      }
                      @case ('select') {
                        <select [value]="selectedComponent()!.settings[field.key]"
                                (change)="onComponentSettingChange(field.key, $event)">
                          @for (opt of field.options; track opt.value) {
                            <option [value]="opt.value">{{ opt.label }}</option>
                          }
                        </select>
                      }
                      @case ('toggle') {
                        <label class="toggle-switch">
                          <input type="checkbox" 
                                 [checked]="selectedComponent()!.settings[field.key]"
                                 (change)="onComponentToggleChange(field.key, $event)">
                          <span class="toggle-slider"></span>
                        </label>
                      }
                    }
                  </div>
                }
              </div>
            }
          </div>
        }
        
        <!-- Global Settings Tab -->
        @if (activeTab() === 'settings') {
          <div class="panel-section">
            <!-- Colors -->
            <div class="accordion" [class.open]="openSettings() === 'colors'">
              <div class="accordion-header" (click)="toggleSettings('colors')">
                <div class="section-title">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/><path d="M12 2a10 10 0 0110 10"/>
                  </svg>
                  <h3>Colors</h3>
                </div>
                <svg class="accordion-icon" [class.open]="openSettings() === 'colors'" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="6,9 12,15 18,9"/>
                </svg>
              </div>
              @if (openSettings() === 'colors') {
                <div class="accordion-content">
                  <div class="control-group">
                    <label>Primary Color</label>
                    <div class="color-input-wrapper">
                      <input type="color" [value]="settings().primaryColor" (input)="onColorChange('primaryColor', $event)">
                      <span class="color-value">{{ settings().primaryColor }}</span>
                    </div>
                  </div>
                  <div class="control-group">
                    <label>Secondary Color</label>
                    <div class="color-input-wrapper">
                      <input type="color" [value]="settings().secondaryColor" (input)="onColorChange('secondaryColor', $event)">
                      <span class="color-value">{{ settings().secondaryColor }}</span>
                    </div>
                  </div>
                  <div class="control-group">
                    <label>Background Color</label>
                    <div class="color-input-wrapper">
                      <input type="color" [value]="settings().bodyBgColor" (input)="onColorChange('bodyBgColor', $event)">
                      <span class="color-value">{{ settings().bodyBgColor }}</span>
                    </div>
                  </div>
                  <div class="control-group">
                    <label>Text Color</label>
                    <div class="color-input-wrapper">
                      <input type="color" [value]="settings().bodyTextColor" (input)="onColorChange('bodyTextColor', $event)">
                      <span class="color-value">{{ settings().bodyTextColor }}</span>
                    </div>
                  </div>
                  <div class="control-group">
                    <label>Header Background</label>
                    <div class="color-input-wrapper">
                      <input type="color" [value]="settings().headerBgColor" (input)="onColorChange('headerBgColor', $event)">
                      <span class="color-value">{{ settings().headerBgColor }}</span>
                    </div>
                  </div>
                  <div class="control-group">
                    <label>Header Text</label>
                    <div class="color-input-wrapper">
                      <input type="color" [value]="settings().headerTextColor" (input)="onColorChange('headerTextColor', $event)">
                      <span class="color-value">{{ settings().headerTextColor }}</span>
                    </div>
                  </div>
                </div>
              }
            </div>
            
            <!-- Typography -->
            <div class="accordion" [class.open]="openSettings() === 'typography'">
              <div class="accordion-header" (click)="toggleSettings('typography')">
                <div class="section-title">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="4,7 4,4 20,4 20,7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/>
                  </svg>
                  <h3>Typography</h3>
                </div>
                <svg class="accordion-icon" [class.open]="openSettings() === 'typography'" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="6,9 12,15 18,9"/>
                </svg>
              </div>
              @if (openSettings() === 'typography') {
                <div class="accordion-content">
                  <div class="control-group">
                    <label>Body Font</label>
                    <select [value]="settings().fontFamily" (change)="onSelectChange('fontFamily', $event)">
                      @for (font of fontOptions; track font.value) {
                        <option [value]="font.value">{{ font.label }}</option>
                      }
                    </select>
                  </div>
                  <div class="control-group">
                    <label>Heading Font</label>
                    <select [value]="settings().headingFontFamily" (change)="onSelectChange('headingFontFamily', $event)">
                      @for (font of fontOptions; track font.value) {
                        <option [value]="font.value">{{ font.label }}</option>
                      }
                    </select>
                  </div>
                  <div class="control-group">
                    <label>Base Font Size: {{ settings().baseFontSize }}px</label>
                    <input type="range" min="12" max="20" [value]="settings().baseFontSize" (input)="onRangeChange('baseFontSize', $event)">
                  </div>
                  <div class="control-group">
                    <label>Heading Size: {{ settings().headingFontSize }}px</label>
                    <input type="range" min="28" max="64" [value]="settings().headingFontSize" (input)="onRangeChange('headingFontSize', $event)">
                  </div>
                </div>
              }
            </div>
            
            <!-- Layout -->
            <div class="accordion" [class.open]="openSettings() === 'layout'">
              <div class="accordion-header" (click)="toggleSettings('layout')">
                <div class="section-title">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/>
                  </svg>
                  <h3>Layout</h3>
                </div>
                <svg class="accordion-icon" [class.open]="openSettings() === 'layout'" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="6,9 12,15 18,9"/>
                </svg>
              </div>
              @if (openSettings() === 'layout') {
                <div class="accordion-content">
                  <div class="control-group">
                    <label>Container Width: {{ settings().containerWidth }}px</label>
                    <input type="range" min="900" max="1400" step="50" [value]="settings().containerWidth" (input)="onRangeChange('containerWidth', $event)">
                  </div>
                  <div class="control-group">
                    <label>Section Padding: {{ settings().sectionPadding }}px</label>
                    <input type="range" min="40" max="120" step="10" [value]="settings().sectionPadding" (input)="onRangeChange('sectionPadding', $event)">
                  </div>
                  <div class="control-group">
                    <label>Border Radius: {{ settings().borderRadius }}px</label>
                    <input type="range" min="0" max="24" step="2" [value]="settings().borderRadius" (input)="onRangeChange('borderRadius', $event)">
                  </div>
                </div>
              }
            </div>
            
            <!-- Site -->
            <div class="accordion" [class.open]="openSettings() === 'site'">
              <div class="accordion-header" (click)="toggleSettings('site')">
                <div class="section-title">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/>
                    <path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>
                  </svg>
                  <h3>Site Info</h3>
                </div>
                <svg class="accordion-icon" [class.open]="openSettings() === 'site'" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="6,9 12,15 18,9"/>
                </svg>
              </div>
              @if (openSettings() === 'site') {
                <div class="accordion-content">
                  <div class="control-group">
                    <label>Site Title</label>
                    <input type="text" [value]="settings().siteTitle" (input)="onTextChange('siteTitle', $event)">
                  </div>
                  <div class="control-group">
                    <label>Tagline</label>
                    <input type="text" [value]="settings().siteTagline" (input)="onTextChange('siteTagline', $event)">
                  </div>
                  <div class="control-group">
                    <label>Footer Text</label>
                    <input type="text" [value]="settings().footerText" (input)="onTextChange('footerText', $event)">
                  </div>
                  <div class="divider"></div>
                  <div class="control-group toggle-row">
                    <span>Show Header</span>
                    <label class="toggle-switch">
                      <input type="checkbox" [checked]="settings().showHeader" (change)="onToggleChange('showHeader', $event)">
                      <span class="toggle-slider"></span>
                    </label>
                  </div>
                  <div class="control-group toggle-row">
                    <span>Sticky Header</span>
                    <label class="toggle-switch">
                      <input type="checkbox" [checked]="settings().stickyHeader" (change)="onToggleChange('stickyHeader', $event)">
                      <span class="toggle-slider"></span>
                    </label>
                  </div>
                  <div class="control-group toggle-row">
                    <span>Show Footer</span>
                    <label class="toggle-switch">
                      <input type="checkbox" [checked]="settings().showFooter" (change)="onToggleChange('showFooter', $event)">
                      <span class="toggle-slider"></span>
                    </label>
                  </div>
                </div>
              }
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .control-panel {
      height: 100%;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    
    .tabs {
      display: flex;
      padding: 0;
      border-bottom: 1px solid var(--border-color);
      flex-shrink: 0;
    }
    
    .tab {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 12px 8px;
      background: transparent;
      border: none;
      border-bottom: 2px solid transparent;
      color: var(--text-secondary);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
      margin-bottom: -1px;
    }
    
    .tab:hover {
      color: var(--text-primary);
      background: var(--bg-gray-50);
    }
    
    .tab.active {
      color: var(--primary-color);
      border-bottom-color: var(--primary-color);
    }
    
    .tab svg {
      flex-shrink: 0;
    }
    
    .tab-content {
      flex: 1;
      overflow-y: auto;
      padding: 12px;
    }
    
    .panel-section {
      /* padding: 12px; */
    }
    
    .section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 6px;
    }
    
    .section-header h3 {
      font-size: 13px;
      font-weight: 600;
      color: var(--text-primary);
    }
    
    .section-desc {
      font-size: 12px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }
    
    .components-grid {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    
    .page-components {
      display: flex;
      flex-direction: column;
    }
    
    .component-settings {
      padding-top: 8px;
    }
    
    .toggle-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .toggle-row span {
      font-size: 13px;
      color: var(--text-primary);
    }
    
    textarea {
      width: 100%;
      padding: 8px 12px;
      background: var(--bg-white);
      border: 1px solid var(--border-color);
      border-radius: 8px;
      color: var(--text-primary);
      font-size: 14px;
      font-family: inherit;
      resize: vertical;
    }
    
    textarea:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    }
  `]
})
export class ControlPanelComponent {
  activeTab = signal<TabType>('components');
  openSettings = signal<SettingsSection | null>('colors');
  
  componentLibrary = COMPONENT_LIBRARY;
  fontOptions = FONT_OPTIONS;
  
  constructor(private customizer: CustomizerService) {}
  
  get settings() {
    return this.customizer.globalSettings;
  }
  
  get components() {
    return this.customizer.components;
  }
  
  get selectedComponentId() {
    return this.customizer.selectedComponentId;
  }
  
  get selectedComponent() {
    return this.customizer.selectedComponent;
  }
  
  setTab(tab: TabType): void {
    this.activeTab.set(tab);
  }
  
  toggleSettings(section: SettingsSection): void {
    this.openSettings.set(this.openSettings() === section ? null : section);
  }
  
  // Component actions
  addComponent(type: string): void {
    this.customizer.addComponent(type as any);
    this.activeTab.set('page');
  }
  
  selectComponent(id: string): void {
    this.customizer.selectComponent(id);
  }
  
  removeComponent(id: string, event: Event): void {
    event.stopPropagation();
    this.customizer.removeComponent(id);
  }
  
  moveComponent(id: string, direction: 'up' | 'down', event: Event): void {
    event.stopPropagation();
    this.customizer.moveComponent(id, direction);
  }
  
  duplicateComponent(id: string, event: Event): void {
    event.stopPropagation();
    this.customizer.duplicateComponent(id);
  }
  
  getComponentName(type: string): string {
    return COMPONENT_LIBRARY.find(c => c.type === type)?.name || type;
  }
  
  getComponentSchema(type: string) {
    return COMPONENT_LIBRARY.find(c => c.type === type)?.settingsSchema || [];
  }
  
  // Component settings changes
  onComponentSettingChange(key: string, event: Event): void {
    const value = (event.target as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement).value;
    const id = this.selectedComponentId();
    if (id) {
      this.customizer.updateComponentSetting(id, key, value);
    }
  }
  
  onComponentToggleChange(key: string, event: Event): void {
    const value = (event.target as HTMLInputElement).checked;
    const id = this.selectedComponentId();
    if (id) {
      this.customizer.updateComponentSetting(id, key, value);
    }
  }
  
  // Global settings changes
  onColorChange(key: keyof GlobalSettings, event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.customizer.updateGlobalSetting(key, value);
  }
  
  onTextChange(key: keyof GlobalSettings, event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.customizer.updateGlobalSetting(key, value as any);
  }
  
  onSelectChange(key: keyof GlobalSettings, event: Event): void {
    const value = (event.target as HTMLSelectElement).value;
    this.customizer.updateGlobalSetting(key, value as any);
  }
  
  onRangeChange(key: keyof GlobalSettings, event: Event): void {
    const value = parseFloat((event.target as HTMLInputElement).value);
    this.customizer.updateGlobalSetting(key, value as any);
  }
  
  onToggleChange(key: keyof GlobalSettings, event: Event): void {
    const value = (event.target as HTMLInputElement).checked;
    this.customizer.updateGlobalSetting(key, value as any);
  }
}
