export const environment = {
  production: false,
  websiteUrl: 'http://localhost:4600'
};
